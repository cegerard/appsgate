/system/bin/dalvikvm -Xms128m  -Xmx256m -classpath bin/felix.jar org.apache.felix.main.Main
